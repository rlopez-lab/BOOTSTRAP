
```HTML
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
      integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
      crossorigin="anonymous"
    />

    <title>Envios - Calculador</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
      <div class="container">
        <a class="navbar-brand" href="index.html">Envíos.com</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#barra"
          aria-controls="barra"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="barra">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="precios.html">Precios</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="calculador.html">Calculador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="promociones.html">Promociones</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="quienes_somos.html">Quiénes Somos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contactenos.html">Contáctenos</a>
            </li>
          </ul>
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="login.html">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="registro.html">Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <main>
      
    </main>

    <footer class="container-fluid py-1 bg-info text-white">
      <div class="row">
        <div class="col text-center">
          Derechos reservados
        </div>
      </div>
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script
      src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
      integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
      integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
      integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
```

```HTML
<div class="py-5 bg-light">
        <div class="col-md-6 m-auto">
                  </div>
      </div>
```

```HTML
<h2 class="text-center">Calculador</h2>


          <form>
            
          </form>


```

```HTML
<div class="form-group">
              <label>Ancho (cm)</label>
              <input
                type="number"
                class="form-control"
                name="ancho"
                placeholder="10"
              />
            </div>
            <div class="form-group">
              <label>Alto (cm)</label>
              <input
                type="number"
                class="form-control"
                name="alto"
                placeholder="15"
              />
            </div>
            <div class="form-group">
              <label>Profundo (cm)</label>
              <input
                type="number"
                class="form-control"
                name="profundo"
                placeholder="5"
              />
            </div>
            <div class="form-group">
              <label>Peso (kg)</label>
              <input
                type="number"
                class="form-control"
                name="peso"
                placeholder="10"
              />
            </div>
            
```


```HTML
<div class="form-group">
              <label for="exampleFormControlSelect1">Origen</label>
              <select class="form-control" name="origen">
                <option>Ciudad 1</option>
                <option>Ciudad 2</option>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Origen</label>
              <select class="form-control" name="destino">
                <option>Ciudad 2</option>
                <option>Ciudad 3</option>
              </select>
            </div>
            
```


```HTML
<div class="form-check form-check-inline">
              <input
                class="form-check-input"
                type="radio"
                name="tipo"
                id="inlineRadio1"
                value="normal"
                checked
              />
              <label class="form-check-label" for="inlineRadio1">Normal</label>
            </div>
            <div class="form-check form-check-inline">
              <input
                class="form-check-input"
                type="radio"
                name="tipo"
                id="inlineRadio2"
                value="express"
              />
              <label class="form-check-label" for="inlineRadio2">Express</label>
            </div>

```

```HTML
            <hr>
          <div class="form-group">
              <label>Precio</label>
              <input
                type="number"
                class="form-control-plaintext"
                name="ancho"
                placeholder="155"
                readonly
              />
            </div>
```
